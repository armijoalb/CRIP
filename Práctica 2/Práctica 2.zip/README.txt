Juan Alberto Mart�nez L�pez
Alberto Armijo Ruiz

Instruciones de instalaci�n y uso

-Instalar python3.

-Hacer cd sobre la carpeta raiz de los ficheros

-Ejecutar cada fichero como el comando python3 (nombre_fichero).py